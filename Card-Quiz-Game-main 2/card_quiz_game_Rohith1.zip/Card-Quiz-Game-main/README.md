# Card-Quiz-Game
An Android app for creating a small quiz game. The app demonstrates multiple activities, usage of Image Assets, Fragments and storing data in Shared Preferences.


![Card_Quiz_Game_0_Splash_Screen](https://user-images.githubusercontent.com/72088607/222603587-503a2ffd-d98b-4edf-9877-da3a82f94ee5.PNG)
![Card_Quiz_Game_2_Register_1](https://user-images.githubusercontent.com/72088607/222603596-a56c6b24-e93d-4d1d-b2b5-2c55494516e0.PNG)
![Card_Quiz_Game_5_Quiz_Question_1_Confirmation](https://user-images.githubusercontent.com/72088607/222603654-29cf12b8-3aff-4072-9d64-28971508bc84.PNG)
![Card_Quiz_Game_6_Quiz_Result](https://user-images.githubusercontent.com/72088607/222603610-01e398ee-76ba-4cee-9900-0a0aeb195b53.PNG)
